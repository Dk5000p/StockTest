﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SelectStock : MonoBehaviour
{
    public GameObject stockDisplay;
    public BoxCollider stock1;
    public BoxCollider stock2;
    public BoxCollider stock3;
    public GameObject rotate;
    public GameObject returnButton;
    public GameObject buyButton;
    public Vector3 location;
    public static GameObject stockSelected;
    public string stockName;
    public float price;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    private void OnMouseDown()
    {
        rotate.SetActive(true);
        returnButton.SetActive(true);
        buyButton.SetActive(true);
        stock1.enabled = false;
        stock2.enabled = false;
        stock3.enabled = false;
        
        stockSelected=Instantiate(stockDisplay, location, Quaternion.identity);
        stockSelected.transform.localScale=new Vector3(2.0f, 2.0f, 0.1f);

    }
    public void DestroyObject()
    {
        Destroy(stockSelected);
        rotate.SetActive(false);
        returnButton.SetActive(false);
        buyButton.SetActive(false);
        stock1.enabled = true;
        stock2.enabled = true;
        stock3.enabled = true;

    }

}
