﻿using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class PopulateTicket : MonoBehaviour
{
    public GameObject returnButton;
    public GameObject buyButton;
    public GameObject rotate;
    public GameObject transactionTicket;
    public string stock;
    public float priceStock1;
    public float priceStock2;
    public float priceStock3;
    public int qty1;
    public int qty2=1;
    public int qty3=1;
    public float count = 0;
    public float total1value;
    public float total2value;
    public float total3value;
    public float subTotal;
    public Text textDisplay;
    public Text stock2Display;
    public Text stock3Display;
    public Text total1;
    public Text total2;
    public Text total3;
    public Text subTotalDisplay;
    public BoxCollider stock1;
    public BoxCollider stock2;
    public BoxCollider stock3;
    public TMP_InputField quantity1;
    public TMP_InputField quantity2;
    public TMP_InputField quantity3;

    public string qty1Text ="1";
    public string qty2Text = "1";
    public string qty3Text = "1";

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        qty1Text = quantity1.text;
        qty1 = int.Parse(qty1Text);
        qty2Text = quantity2.text;
        qty2 = int.Parse(qty2Text);
        qty3Text = quantity3.text;
        qty3 = int.Parse(qty3Text);
        total1value = qty1 * priceStock1;
        total1.text = total1value.ToString();
        total2value = qty2 * priceStock2;
        total2.text = total2value.ToString();
        total3value = qty3 * priceStock3;
        total3.text = total3value.ToString();
        subTotal = total1value + total2value + total3value;
        subTotalDisplay.text = "Ticket Total " + subTotal.ToString();

    }
    public void AddStock()
    {


        returnButton.SetActive(false);
        buyButton.SetActive(false);
        rotate.SetActive(false);
        transactionTicket.SetActive(true);
        stock1.enabled = true;
        stock2.enabled = true;
        stock3.enabled = true;
        

        if (SelectStock.stockSelected.tag == "Stock 1" && count == 0)
        {
            textDisplay.text = "Stock1";
            quantity1.enabled = true;
            priceStock1 = 1.13f;
            stock1.enabled = false;
            Destroy(SelectStock.stockSelected);
            count++;

        }
        else if (SelectStock.stockSelected.tag == "Stock 2" && count == 0)
        {
            textDisplay.text = "Stock2";
            quantity1.enabled = true;
            priceStock1 = 11.47f;
          
            stock2.enabled = false;
            Destroy(SelectStock.stockSelected);
            count++;

        }
        else if (SelectStock.stockSelected.tag == "Stock 3" && count == 0)
        {
            textDisplay.text = "Stock3";
            quantity1.enabled = true;
            priceStock1 = 21.42f;
            stock3.enabled = false;
            Destroy(SelectStock.stockSelected);
            count++;

        }
        else if (SelectStock.stockSelected.tag == "Stock 1" && count == 1)
        {
            stock2Display.text = "Stock1";
            quantity1.enabled = true;
            priceStock2 = 1.13f;
           
            stock1.enabled = false;
            Destroy(SelectStock.stockSelected);
            count++;

        }
        else if (SelectStock.stockSelected.tag == "Stock 2" && count == 1)
        {
            stock2Display.text = "Stock2";
            quantity1.enabled = true;
            priceStock2 = 11.47f;
            stock2.enabled = false;
            Destroy(SelectStock.stockSelected);
            count++;

        }
        else if (SelectStock.stockSelected.tag == "Stock 3" && count == 1)
        {
            stock2Display.text = "Stock3";
            quantity1.enabled = true;
            priceStock2 = 21.42f;
            stock3.enabled = false;
            Destroy(SelectStock.stockSelected);
            count++;

        }
        else if (SelectStock.stockSelected.tag == "Stock 1" && count == 2)
        {
            stock3Display.text = "Stock1";
            quantity1.enabled = true;
            priceStock3 = 1.13f;
           
            stock1.enabled = false;
            Destroy(SelectStock.stockSelected);
            count++;

        }
        else if (SelectStock.stockSelected.tag == "Stock 2" && count == 2)
        {
            stock3Display.text = "Stock2";
            quantity1.enabled = true;
            priceStock3 = 11.47f;
            
            stock2.enabled = false;
            Destroy(SelectStock.stockSelected);
            count++;

        }
        else if (SelectStock.stockSelected.tag == "Stock 3" && count == 2)
        {
            stock3Display.text = "Stock3";
            quantity1.enabled = true;
            priceStock3 = 21.42f;
           
            stock3.enabled = false;
            Destroy(SelectStock.stockSelected);
            count++;

        }
    }
}
